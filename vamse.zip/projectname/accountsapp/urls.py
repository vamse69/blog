from django.urls import path
from .views import *
urlpatterns =[
    path('signup/',register, name='signup'),
    path('login/', login, name='login'),
    path('logout/', logout_view, name='logout'),

]