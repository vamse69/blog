from django.apps import AppConfig


class AccountsappConfig(AppConfig):
    name = 'accountsapp'
